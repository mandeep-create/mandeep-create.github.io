#!/bin/sh
# Mother Sentinel: watches your open-source and secure-source code, flags anomalies, signals events to the wall.
# Read-only. (c) 2026 Mandeep S. Bhullar - SpinalXeno(TM). All rights reserved. SpinalXeno(TM) is a trademark of Mandeep S. Bhullar.
# fingerprint 25666eb2cf27368640bb41154733bfdc1f8a07b194aec7661659fc7b565155b3
cd "$(dirname "$0")"
exec perl -x "$0" "$@"
#!perl
# Mother Sentinel (Mac / Linux / Unix). Read-only: it never changes, uploads or deletes anything it watches.
use strict; use warnings; use utf8; use File::Find; use Digest::SHA; use File::Basename; use Cwd 'abs_path';
binmode STDOUT, ':encoding(UTF-8)'; $| = 1;
my $KIT = dirname(abs_path($0)); my $HOME = $ENV{HOME} || '';
my $CONF = "$KIT/sentinel.conf"; my $OUT = "$KIT/mother-events.js"; my $LOG = "$KIT/mother-events.log";
my $EVERY = 10; my $MAC = $^O eq 'darwin';
unless (-e $CONF) {
  open my $c, '>:encoding(UTF-8)', $CONF or die "cannot write $CONF\n";
  print $c "# Mother Sentinel watch list.  kind|path   kinds: open (public, signed), secure (private), kit (this folder)\n# Lines starting with # are ignored. ~ means your home folder.\n";
  print $c "kit|.\n";
  print $c "open|~/XenoChickenBalls-site\n"   if -d "$HOME/XenoChickenBalls-site";
  print $c "secure|~/XenoChickenBalls-source\n" if -d "$HOME/XenoChickenBalls-source";
  print $c "# open|/path/to/another/public/project\n# secure|/path/to/another/private/project\n"; close $c;
}
my @W; open my $cf, '<:encoding(UTF-8)', $CONF or die; while (<$cf>) { chomp; s/\r//; next if /^\s*(#|$)/; my ($k,$p) = split /\|/, $_, 2; next unless $p;
  $p =~ s/^~/$HOME/; $p = $KIT if $p eq '.'; push @W, {kind=>$k, path=>$p, name=>($p eq $KIT ? 'kit' : basename($p)), snap=>undef, head=>'', s=>'wait', d=>'baseline…'} } close $cf;
my (@EV, $n); my %C = (ok=>"\e[38;2;57;255;136m", bad=>"\e[38;2;255;79;123m", wait=>"\e[38;2;201;211;255m"); my %M = (ok=>'●', bad=>'○', wait=>'◌');
sub jq { my $s = shift; $s =~ s/([\\"])/\\$1/g; $s =~ s/[\x00-\x1f]/ /g; return "\"$s\"" }
sub ev { my ($k,$src,$msg) = @_; my $t = int(Time::HiRes::time()*1000); push @EV, {id=>$t.'-'.(++$n), k=>$k, src=>$src, msg=>$msg, t=>$t}; shift @EV while @EV > 300;
  my $ts = localtime; print "$C{$k}$M{$k} \e[2m$ts\e[22m  $src  \e[1m$msg\e[0m\n";
  if (open my $l, '>>:encoding(UTF-8)', $LOG) { print $l "$ts\t$k\t$src\t$msg\n"; close $l }
  if ($k eq 'bad') { print "\a"; if ($MAC) { my $m = $msg; $m =~ s/["\\]//g; system('osascript', '-e', "display notification \"$m\" with title \"Mother Sentinel · ANOMALY\" subtitle \"$src\" sound name \"Basso\"") }
    elsif (-x '/usr/bin/notify-send') { system('notify-send', '-u', 'critical', 'Mother Sentinel · ANOMALY', "$src: $msg") } } }
use Time::HiRes;
sub write_feed { my $j = "window.__motherEvents={t:".int(Time::HiRes::time()*1000).",status:[".join(',', map { "{kind:".jq($_->{kind}).",name:".jq($_->{name}).",s:".jq($_->{s}).",d:".jq($_->{d})."}" } @W)."],ev:[".
  join(',', map { "{id:".jq($_->{id}).",k:".jq($_->{k}).",src:".jq($_->{src}).",msg:".jq($_->{msg}).",t:$_->{t}}" } @EV)."]};\n";
  if (open my $o, '>:encoding(UTF-8)', "$OUT.tmp") { print $o $j; close $o; rename "$OUT.tmp", $OUT } }
sub sha { my $f = shift; my $d = eval { Digest::SHA->new(256)->addfile($f, 'b')->hexdigest }; return $d // '' }
sub scan { my $w = shift; my %s; my $root = $w->{path};
  find({ no_chdir=>1, wanted=>sub { if (-d $_) { $File::Find::prune = 1 if m{/(\.git|node_modules|\.venv|__pycache__)$}; return }
    my $r = substr($File::Find::name, length($root)+1); return if $r =~ /^(mother-events\.(js|js\.tmp|log)|sentinel\.conf|\.DS_Store)$/ || $r =~ m{/\.DS_Store$};
    my @st = stat($_); $s{$r} = [$st[9], $st[7]] } }, $root);
  return \%s }
sub secret { my $f = shift; return 0 if -s $f > 2_000_000; open my $h, '<', $f or return 0; local $/; my $x = <$h>; close $h; return $x =~ /-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}/ ? 1 : 0 }
sub sums_check { my $w = shift; my $sf = "$w->{path}/signature/SHA256SUMS"; return (0, 'no signature list') unless -e $sf; my ($bad, $all) = (0, 0);
  open my $h, '<', $sf or return (0, 'unreadable'); my %listed; while (<$h>) { chomp; my ($d, $f) = /^(\w+)\s+\*?(.+)$/ or next; $all++; $listed{$f} = 1; my $p = "$w->{path}/$f";
    if (!-e $p) { $bad++; ev('bad', "open $w->{name}", "Signed file missing: $f") } elsif (sha($p) ne $d) { $bad++; ev('bad', "open $w->{name}", "Unsigned change: $f (hash differs from signed list)") } } close $h;
  my $sig = -e "$sf.sig" && -e "$w->{path}/signature/SpinalXeno-public-key.pem" ? system("openssl dgst -sha256 -verify '$w->{path}/signature/SpinalXeno-public-key.pem' -signature '$sf.sig' '$sf' >/dev/null 2>&1") == 0 : undef;
  if (defined $sig && !$sig) { $bad++; ev('bad', "open $w->{name}", 'Signature on SHA256SUMS does NOT verify') }
  return ($bad, $bad ? "$bad problem(s) in $all signed files" : "$all files match · signature ".(defined $sig ? 'valid' : 'not checked (no openssl)'), \%listed) }
sub git { my ($p, $cmd) = @_; return '' unless -d "$p/.git"; my $o = `git -C '$p' $cmd 2>/dev/null`; utf8::decode($o); chomp $o; return $o }
my %KITSUM; if (open my $m, '<', "$KIT/MANIFEST.sha256") { while (<$m>) { my ($d, $f) = /^(\w+)\s+\*?(.+)$/ or next; $KITSUM{$f} = $d } }
print "\e]0;Mother Sentinel\a\e[38;2;57;255;136m\e[1mTHE MOTHER OF ALL OF ALL · SENTINEL\e[0m  watching ".scalar(@W)." source(s) every ${EVERY}s · Ctrl+C to stop\n\e[2m© 2026 Mandeep S. Bhullar · SpinalXeno™ · read-only: nothing watched is ever changed or sent anywhere\e[0m\n\n";
$SIG{INT} = $SIG{TERM} = sub { ev('wait', 'sentinel', 'Sentinel stopped'); write_feed(); exit 0 };
ev('wait', 'sentinel', 'Sentinel started · '.join(', ', map { "$_->{kind}:$_->{name}" } @W));
while (1) {
  for my $w (@W) { my $tag = "$w->{kind} $w->{name}";
    unless (-d $w->{path}) { if ($w->{s} ne 'bad') { ev('bad', $tag, "Folder missing or drive unplugged: $w->{path}") } $w->{s} = 'bad'; $w->{d} = 'missing'; $w->{snap} = undef; next }
    my $now = scan($w); my $old = $w->{snap}; my (@add, @chg, @del);
    if ($old) { for (keys %$now) { if (!$old->{$_}) { push @add, $_ } elsif ($old->{$_}[0] != $now->{$_}[0] || $old->{$_}[1] != $now->{$_}[1]) { push @chg, $_ } } for (keys %$old) { push @del, $_ unless $now->{$_} } }
    my $flag = 0;
    if (@add + @chg + @del) { my $k = 'ok';
      ev($k, $tag, "Added: $_") for @add[0..($#add < 7 ? $#add : 7)]; ev($k, $tag, "Changed: $_") for @chg[0..($#chg < 7 ? $#chg : 7)]; ev($k, $tag, "Deleted: $_") for @del[0..($#del < 7 ? $#del : 7)];
      my $tot = @add + @chg + @del; ev('bad', "anomaly detector", "$tag: burst of $tot changes in ${EVERY}s") if $tot > 25 || @del > 5;
      for (@add, @chg) { my $p = "$w->{path}/$_"; if (secret($p)) { $flag++; ev('bad', $tag, ($w->{kind} eq 'open' ? 'SECRET IN PUBLIC CODE: ' : 'Secret found: ')."$_ contains a private key or token") } } }
    elsif (!$old) { for (keys %$now) { my $p = "$w->{path}/$_"; if ($w->{kind} eq 'open' && /\.pem$|\.key$/ && secret($p)) { $flag++; ev('bad', $tag, "SECRET IN PUBLIC CODE: $_") } } }
    $w->{snap} = $now; my $files = keys %$now; my @d = ("$files files");
    if ($w->{kind} eq 'kit' && %KITSUM && (!$old || @add + @chg + @del)) { my $bad = 0; for (keys %KITSUM) { my $p = "$KIT/$_"; if (!-e $p || sha($p) ne $KITSUM{$_}) { $bad++; ev('bad', $tag, "Kit tampered: $_ differs from the signed manifest") } } $w->{kd} = $bad ? "$bad tampered" : 'manifest intact'; $w->{kb} = $bad } if ($w->{kind} eq 'kit' && %KITSUM) { push @d, $w->{kd}; $flag += $w->{kb} }
    if ($w->{kind} eq 'open' && (!$old || @add + @chg + @del)) { my ($bad, $msg) = sums_check($w); $w->{sums} = $msg; $w->{sb} = $bad } if ($w->{sums}) { push @d, $w->{sums}; $flag += $w->{sb} }
    my $head = git($w->{path}, 'log -1 --format=%h·%s');
    if ($head) { ev('ok', $tag, "New commit $head") if $w->{head} && $head ne $w->{head}; $w->{head} = $head; my $dirty = () = split /\n/, git($w->{path}, 'status --porcelain'); push @d, "git $head".($dirty ? " · $dirty uncommitted" : ' · clean');
      if ($w->{kind} eq 'secure' && !$w->{vis} ) { my $url = git($w->{path}, 'remote get-url origin'); if ($url =~ m{github\.com[/:]([^/]+/[^/.]+)}) { my $code = `curl -s -o /dev/null -m 8 -w '%{http_code}' https://api.github.com/repos/$1 2>/dev/null`;
          if ($code eq '200') { $flag++; ev('bad', $tag, "PRIVATE REPO IS PUBLIC: $1") } elsif ($code eq '404') { ev('ok', $tag, "Private repo $1 is hidden from the public") } $w->{vis} = $code } } }
    $w->{s} = $flag ? 'bad' : 'ok'; $w->{d} = join(' · ', @d);
    ev('ok', $tag, "Baseline: ".join(' · ', @d)) unless $old; }
  write_feed(); sleep $EVERY;
}
