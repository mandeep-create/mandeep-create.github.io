@echo off
rem The Mother of All of All - Echo: terminal rain of every script. Runs until you extract the echo (E, Q or Esc).
rem (c) 2026 Mandeep S. Bhullar - SpinalXeno(TM). All rights reserved. SpinalXeno(TM) is a trademark of Mandeep S. Bhullar.
rem fingerprint 25666eb2cf27368640bb41154733bfdc1f8a07b194aec7661659fc7b565155b3
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$f='%~f0';$s=[IO.File]::ReadAllText($f,[Text.Encoding]::UTF8);$a=$s.LastIndexOf('#'+'##PS');$b=$s.LastIndexOf('#'+'##DATA');& ([ScriptBlock]::Create($s.Substring($a+6,$b-$a-6))) $f"
exit /b
###PS

$ErrorActionPreference='SilentlyContinue'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$Host.UI.RawUI.WindowTitle='The Mother of All of All - Echo'
Add-Type -Name W -Namespace M -MemberDefinition '[DllImport("kernel32.dll")]public static extern System.IntPtr GetConsoleWindow();[DllImport("user32.dll")]public static extern bool ShowWindow(System.IntPtr h,int c);'
[M.W]::ShowWindow([M.W]::GetConsoleWindow(),3) | Out-Null
if($env:WT_SESSION){(New-Object -ComObject WScript.Shell).SendKeys('{F11}')}
Start-Sleep -Milliseconds 400
$src=[IO.File]::ReadAllText($args[0],[Text.Encoding]::UTF8)
$rows=$src.Substring($src.LastIndexOf('#'+'##DATA')+8).Trim() -split "`r?`n"
$S=foreach($r in $rows){$p=$r -split '\|',3; $g=[Globalization.StringInfo]::GetTextElementEnumerator($p[2]); $a=@(); while($g.MoveNext()){$a+=$g.Current}; [pscustomobject]@{c=$p[0];n=$p[1];g=$a}}
$C=@{rws='Green';read='Yellow';write='Red';shared='Gray';speak='Cyan'}
$L=@{rws='Read-Write-Speak (node)';read='Read only (antinode)';write='Write only (antinode)';shared='Shared (no-node)';speak='Speak only (no-node)'}
$R=New-Object Random
function Fit{ $script:W=[Console]::WindowWidth; $script:H=[Console]::WindowHeight-2; $script:N=[Math]::Floor($W/2)
  $script:Y=New-Object int[] $N; $script:Sc=New-Object object[] $N; $script:Sp=New-Object int[] $N
  for($i=0;$i -lt $N;$i++){$Y[$i]=-$R.Next(0,$H);$Sc[$i]=$S[$R.Next($S.Count)];$Sp[$i]=$R.Next(1,3)}
  [Console]::BackgroundColor='Black'; Clear-Host }
[Console]::CursorVisible=$false; Fit; $t=0; $pause=$false; $feat=$S[0]
try{ while($true){
  if([Console]::KeyAvailable){$k=[Console]::ReadKey($true)
    if($k.Key -eq 'Q' -or $k.Key -eq 'Escape' -or $k.Key -eq 'E'){break}
    if($k.Key -eq 'Spacebar'){$pause=-not $pause}}
  if($W -ne [Console]::WindowWidth -or $H -ne [Console]::WindowHeight-2){Fit}
  if($pause){Start-Sleep -Milliseconds 80; continue}
  $t++
  for($i=0;$i -lt $N;$i++){ if(($t % $Sp[$i]) -ne 0){continue}; $y=$Y[$i]; $s=$Sc[$i]; $x=$i*2
    if($y -ge 0 -and $y -lt $H){[Console]::SetCursorPosition($x,$y);[Console]::ForegroundColor='White';[Console]::Write($s.g[$R.Next($s.g.Count)])
      if($y -ge 1){[Console]::SetCursorPosition($x,$y-1);[Console]::ForegroundColor=$C[$s.c];[Console]::Write($s.g[$R.Next($s.g.Count)])}}
    $e=$y-14; if($e -ge 0 -and $e -lt $H){[Console]::SetCursorPosition($x,$e);[Console]::Write('  ')}
    $Y[$i]++; if($e -ge $H){$Y[$i]=-$R.Next(0,8);$Sc[$i]=$S[$R.Next($S.Count)];$Sp[$i]=$R.Next(1,3)} }
  if(($t % 60) -eq 1){$feat=$S[$R.Next($S.Count)]}
  [Console]::SetCursorPosition(0,$H);[Console]::ForegroundColor=$C[$feat.c]
  $line=(' * '+$feat.n+'  -  '+$L[$feat.c]+'  -  '+($feat.g -join ' ')+'      [Space] pause  [E]/[Q]/[Esc] extract the echo').PadRight($W-1)
  [Console]::Write($line.Substring(0,[Math]::Min($line.Length,$W-1)))
  [Console]::SetCursorPosition(0,$H+1);[Console]::ForegroundColor='DarkGray'
  $cr='(c) 2026 Mandeep S. Bhullar - SpinalXeno(TM) - 182 scripts of Unicode 18.0 + unencoded + oral/sign'; [Console]::Write($cr.Substring(0,[Math]::Min($cr.Length,$W-1)))
  Start-Sleep -Milliseconds 45 } }
finally{ [Console]::ResetColor(); Clear-Host; [Console]::CursorVisible=$true; Write-Host ''; Write-Host '  ECHO EXTRACTED.' -ForegroundColor Green; Write-Host '' }

###DATA
rws|Adlam|𞤀𞤅𞤋𞤑𞤗𞤜𞤢𞤨𞤮𞤳𞤹𞤿
read|Ahom|𑜀𑜂𑜅𑜈𑜋𑜎𑜑𑜓𑜖𑜙𑝁𑝄
read|Anatolian Hieroglyphs|𔐀𔐕𔐪𔑀𔑕𔑪𔒀𔒕𔒪𔓀𔓕𔓪
rws|Arabic|ابتثجحخدذرزس
rws|Armenian|ԱԷԾՅՌՓաըկնսք
read|Avestan|𐬀𐬄𐬉𐬍𐬒𐬖𐬛𐬟𐬤𐬨𐬭𐬱
rws|Balinese|ᬅᬉᬎᬒᬗᬛᬠᬥᬩᬮᬲᭈ
rws|Bamum|ꚠꚥꚫꚱꚷꚽꛃꛈꛎꛔꛚꛠ
rws|Bassa Vah|𖫐𖫒𖫕𖫗𖫚𖫜𖫟𖫡𖫤𖫦𖫩𖫫
rws|Batak|ᯀᯃᯆᯉᯌᯏᯓᯖᯙᯜᯟᯢ
rws|Bengali|ঀঈএকচঞণনভশঽৠ
rws|Beria Erfe|𖺠𖺤𖺨𖺬𖺰𖺴𖺻𖺿𖻃𖻇𖻋𖻏
read|Bhaiksuki|𑰀𑰃𑰇𑰌𑰐𑰔𑰘𑰜𑰠𑰤𑰨𑰬
rws|Bopomofo|ㄅㄋㄑㄗㄞㄤㄪㆠㆧㆭㆳㆹ
read|Brahmi|𑀃𑀇𑀌𑀑𑀕𑀚𑀟𑀣𑀨𑀭𑀱𑀶
rws|Braille|⠀⠕⠪⡀⡕⡪⢀⢕⢪⣀⣕⣪
rws|Buginese|ᨀᨁᨃᨅᨇᨉᨋᨍᨏᨑᨓᨕ
rws|Buhid|ᝀᝁᝃᝄᝆᝇᝉᝊᝌᝍᝏᝐ
rws|Canadian Aboriginal|ᐁᐖᐫᑁᑖᑫᒁᒖᒫᓁᓖᓫ
read|Carian|𐊠𐊤𐊨𐊬𐊰𐊴𐊸𐊼𐋀𐋄𐋈𐋌
read|Caucasian Albanian|𐔰𐔴𐔸𐔽𐕁𐕅𐕊𐕎𐕒𐕗𐕛𐕟
rws|Chakma|𑄃𑄆𑄉𑄌𑄏𑄒𑄖𑄙𑄜𑄟𑄢𑄥
rws|Cham|ꨀꨄꨈꨍꨑꨕꨚꨞꨢꨧꩂꩇ
rws|Cherokee|ᎠᎧᎯᎷᎾᏆᏎᏕᏝᏥᏬᏴ
read|Chorasmian|𐾰𐾱𐾳𐾵𐾷𐾸𐾺𐾼𐾾𐾿𐿁𐿃
shared|Common|⁰⓺❸㎦𜴰𝁃𝐘𝚕🃌🐹🚞🥱
rws|Coptic|ϢϣϤϥϦϧϩϪϫϬϭϮ
read|Cuneiform|𒀀𒀕𒀪𒁀𒁕𒁪𒂀𒂕𒂪𒃀𒃕𒃪
read|Cypriot|𐠀𐠄𐠌𐠐𐠕𐠙𐠞𐠣𐠧𐠬𐠰𐠵
write|Cypro Minoan|𒾐𒾘𒾠𒾨𒾰𒾸𒿀𒿈𒿐𒿘𒿠𒿨
rws|Cyrillic|ЀДЩођѧѼҘҭӂӖӫ
rws|Deseret|𐐀𐐆𐐍𐐔𐐚𐐡𐐨𐐮𐐵𐐼𐑂𐑉
rws|Devanagari|ऄऊऑघटथबळऽड़ॲॹ
read|Dives Akuru|𑤀𑤃𑤉𑤏𑤒𑤘𑤜𑤟𑤣𑤧𑤪𑤮
read|Dogra|𑠀𑠃𑠇𑠋𑠎𑠒𑠖𑠙𑠝𑠡𑠤𑠨
rws|Duployan|𛰀𛰋𛰗𛰢𛰮𛰹𛱅𛱑𛱜𛱨𛱸𛲇
read|Egyptian Hieroglyphs|𓀀𓀕𓀪𓁀𓁕𓁪𓂀𓂕𓂪𓃀𓃕𓃪
read|Elbasan|𐔀𐔃𐔆𐔊𐔍𐔐𐔔𐔗𐔚𐔞𐔡𐔤
read|Elymaic|𐿠𐿡𐿣𐿥𐿧𐿩𐿫𐿭𐿯𐿱𐿳𐿵
rws|Ethiopic|ሀሓሧሻቒቪቾኔከዀዘዬ
rws|Garay|𐵊𐵎𐵒𐵖𐵛𐵟𐵣𐵰𐵵𐵹𐵽𐶁
rws|Georgian|ႠႧႮႵႽჄდლტჩჰჷ
read|Glagolitic|ⰀⰈⰐⰘⰠⰨⰰⰸⱀⱈⱐⱘ
read|Gothic|𐌰𐌲𐌴𐌶𐌸𐌺𐌼𐌾𐍀𐍃𐍅𐍇
read|Grantha|𑌅𑌉𑌏𑌖𑌚𑌟𑌣𑌧𑌭𑌲𑌸𑍝
rws|Greek|ͰͽΑΚΥήθρϋϔϞϵ
rws|Gujarati|અઉઍઔઘઝડથફયશઽ
rws|Gunjala Gondi|𑵠𑵣𑵧𑵬𑵯𑵳𑵶𑵹𑵽𑶀𑶄𑶇
rws|Gurmukhi|ਅਉਓਗਜਠਤਨਮਲ਼ਹੜ
rws|Gurung Khema|𖄀𖄂𖄅𖄇𖄊𖄌𖄏𖄑𖄔𖄖𖄙𖄛
rws|Han|一响宛扩椷瀅盓綠葮謼鈊飘
rws|Hangul|가꾣덆뛩몌븯쇒앵줘첻큞퐁
rws|Hanifi Rohingya|𐴀𐴃𐴆𐴉𐴌𐴏𐴒𐴕𐴘𐴛𐴞𐴡
rws|Hanunoo|ᜠᜡᜣᜤᜦᜧᜩᜪᜬᜭᜯᜰ
read|Hatran|𐣠𐣡𐣣𐣥𐣧𐣨𐣪𐣬𐣮𐣯𐣱𐣴
rws|Hebrew|אגוחךלןעפקשװ
rws|Hiragana|ぁえくしぞてねぴぼゃるを
read|Imperial Aramaic|𐡀𐡁𐡃𐡅𐡇𐡉𐡋𐡌𐡎𐡐𐡒𐡔
shared|Inherited|◌́◌̈◌̃◌̱◌͠
read|Inscriptional Pahlavi|𐭠𐭡𐭣𐭤𐭦𐭧𐭩𐭫𐭬𐭮𐭯𐭱
read|Inscriptional Parthian|𐭀𐭁𐭃𐭅𐭇𐭉𐭋𐭌𐭎𐭐𐭒𐭔
rws|Javanese|ꦄꦇꦋꦏꦓꦗꦛꦟꦣꦧꦫꦯ
read|Jurchen|𘸀𘸕𘸪𘹀𘹕𘹪𘺀𘺕𘺪𘻀𘻕𘻪
read|Kaithi|𑂃𑂆𑂊𑂎𑂒𑂕𑂙𑂝𑂡𑂤𑂨𑂬
rws|Kannada|ಀಈಎಔಙಞಣಧಭಲಸೞ
rws|Katakana|ァエグジダデハプミユヮヶ
read|Kawi|𑼂𑼇𑼋𑼏𑼔𑼘𑼜𑼠𑼤𑼨𑼬𑼰
rws|Kayah Li|ꤊꤌꤎꤑꤓꤕꤘꤚꤜꤟꤡꤣ
read|Kharoshthi|𐨀𐨒𐨖𐨚𐨝𐨠𐨣𐨦𐨩𐨬𐨯𐨲
write|Khitan Small Script|𘬀𘬕𘬪𘭀𘭕𘭪𘮀𘮕𘮪𘯀𘯕𘯪
rws|Khmer|កងញឍធពលសឤឨឭឱ
read|Khojki|𑈀𑈃𑈇𑈋𑈏𑈓𑈗𑈛𑈟𑈢𑈦𑈪
read|Khudawadi|𑊰𑊳𑊷𑊻𑊿𑋃𑋇𑋋𑋏𑋓𑋗𑋛
rws|Kirat Rai|𖵀𖵃𖵇𖵋𖵏𖵒𖵖𖵚𖵞𖵡𖵥𖵩
rws|Lao|ກງຍຒຖປຠລຫະເໆ
rws|Latin|AaBbCcÐðÆæŒœ
rws|Lepcha|ᰀᰃᰆᰉᰍᰐᰓᰖᰚᰝᰠᰣ
rws|Limbu|ᤀᤂᤅᤇᤊᤌᤏᤒᤔᤗᤙᤜ
write|Linear A|𐘀𐘕𐘪𐙀𐙕𐙪𐚀𐚕𐚪𐛀𐛕𐛪
read|Linear B|𐀀𐀒𐀤𐀶𐁊𐁝𐂑𐂣𐂴𐃆𐃗𐃩
rws|Lisu|ꓐꓓꓗꓛꓟꓣꓧꓪꓮꓲꓶꓺ
read|Lycian|𐊀𐊂𐊄𐊇𐊉𐊌𐊎𐊐𐊓𐊕𐊘𐊚
read|Lydian|𐤠𐤢𐤤𐤦𐤨𐤪𐤭𐤯𐤱𐤳𐤵𐤷
read|Mahajani|𑅐𑅓𑅖𑅙𑅜𑅟𑅢𑅥𑅨𑅫𑅮𑅱
read|Makasar|𑻠𑻡𑻣𑻤𑻦𑻧𑻩𑻫𑻬𑻮𑻯𑻱
rws|Malayalam|ഄഉഐഖജഡധഭലസൔൺ
rws|Mandaic|ࡀࡂࡄࡆࡈࡊࡌࡎࡐࡒࡔࡖ
read|Manichaean|𐫀𐫃𐫆𐫊𐫍𐫐𐫓𐫖𐫙𐫜𐫟𐫢
read|Marchen|𑱲𑱴𑱷𑱹𑱼𑱾𑲁𑲃𑲆𑲈𑲋𑲍
rws|Masaram Gondi|𑴀𑴄𑴉𑴎𑴒𑴖𑴚𑴞𑴢𑴦𑴪𑴮
rws|Medefaidrin|𖹀𖹅𖹊𖹐𖹕𖹚𖹠𖹥𖹪𖹰𖹵𖹺
rws|Meetei Mayek|ꫠꫣꫧꫲꯁꯅꯉꯌꯐꯔꯘꯜ
rws|Mende Kikakui|𞠀𞠐𞠠𞠱𞡁𞡒𞡢𞡲𞢃𞢓𞢤𞢴
read|Meroitic Cursive|𐦠𐦢𐦤𐦦𐦨𐦪𐦭𐦯𐦱𐦳𐦵𐦷
read|Meroitic Hieroglyphs|𐦀𐦂𐦅𐦈𐦊𐦍𐦐𐦒𐦕𐦘𐦚𐦝
rws|Miao|𖼀𖼇𖼎𖼖𖼝𖼥𖼬𖼳𖼻𖽂𖽊𖾘
read|Modi|𑘀𑘄𑘈𑘌𑘐𑘔𑘘𑘜𑘠𑘤𑘨𑘬
rws|Mongolian|ᠠᠪᠵᡀᡋᡕᡠᡫᡶᢉᢔᢟ
rws|Mro|𖩀𖩂𖩅𖩇𖩊𖩌𖩏𖩒𖩔𖩗𖩙𖩜
read|Multani|𑊀𑊃𑊆𑊋𑊏𑊒𑊕𑊘𑊛𑊟𑊢𑊥
rws|Myanmar|ကဆဌဒဘသဥဿၕၥၶၼ
read|Nabataean|𐢀𐢂𐢅𐢇𐢊𐢌𐢏𐢒𐢔𐢗𐢙𐢜
rws|Nag Mundari|𞓐𞓒𞓔𞓗𞓙𞓛𞓞𞓠𞓢𞓥𞓧𞓩
read|Nandinagari|𑦠𑦤𑦪𑦮𑦲𑦶𑦺𑦾𑧂𑧆𑧊𑧎
rws|New Tai Lue|ᦀᦅᦋᦑᦗᦝᦣᦨᦲᦸᦾᧄ
rws|Newa|𑐀𑐅𑐊𑐏𑐔𑐙𑐞𑐣𑐨𑐭𑐲𑑉
rws|Nko|ߊߍߐߓߖߙߜߟߢߥߨߴ
read|Nushu|𖿡
rws|Nyiakeng Puachue Hmong|𞄀𞄄𞄈𞄍𞄑𞄖𞄚𞄞𞄣𞄧𞄬𞄺
read|Ogham|ᚁᚃᚅᚇᚉᚋᚎᚐᚒᚔᚖᚘ
rws|Ol Chiki|ᱚᱝᱠᱣᱦᱩᱬᱯᱲᱵᱸᱻ
rws|Ol Onal|𞗐𞗒𞗕𞗗𞗚𞗜𞗟𞗢𞗤𞗧𞗩𞗬
read|Old Hungarian|𐲀𐲈𐲑𐲙𐲢𐲪𐳀𐳈𐳑𐳙𐳢𐳪
read|Old Italic|𐌀𐌂𐌅𐌈𐌋𐌎𐌑𐌔𐌗𐌚𐌝𐌭
read|Old North Arabian|𐪀𐪂𐪄𐪇𐪉𐪌𐪎𐪐𐪓𐪕𐪘𐪚
read|Old Permic|𐍐𐍓𐍖𐍙𐍜𐍟𐍣𐍦𐍩𐍬𐍯𐍲
read|Old Persian|𐎠𐎣𐎧𐎫𐎮𐎲𐎶𐎹𐎽𐏁𐏈𐏌
read|Old Sogdian|𐼀𐼂𐼅𐼇𐼊𐼌𐼏𐼑𐼔𐼖𐼙𐼛
read|Old South Arabian|𐩠𐩢𐩤𐩧𐩩𐩬𐩮𐩰𐩳𐩵𐩸𐩺
read|Old Turkic|𐰀𐰆𐰌𐰒𐰘𐰞𐰤𐰪𐰰𐰶𐰼𐱂
read|Old Uyghur|𐽰𐽱𐽳𐽴𐽶𐽷𐽹𐽺𐽼𐽽𐽿𐾀
rws|Oriya|ଅଉଏଖଚଟଣଧଭଲସଢ଼
rws|Osage|𐒰𐒶𐒼𐓂𐓈𐓎𐓘𐓞𐓤𐓪𐓰𐓶
rws|Osmanya|𐒀𐒂𐒅𐒇𐒊𐒌𐒏𐒑𐒔𐒖𐒙𐒛
rws|Pahawh Hmong|𖬀𖬇𖬏𖬗𖬞𖬦𖬮𖭤𖭬𖭴𖮀𖮈
read|Palmyrene|𐡠𐡡𐡣𐡥𐡧𐡩𐡫𐡭𐡯𐡱𐡳𐡵
read|Pau Cin Hau|𑫀𑫄𑫉𑫎𑫓𑫗𑫜𑫡𑫦𑫪𑫯𑫴
read|Phags Pa|ꡀꡄꡈꡍꡑꡕꡚꡞꡢꡧꡫꡯ
read|Phoenician|𐤀𐤁𐤃𐤅𐤇𐤉𐤋𐤌𐤎𐤐𐤒𐤔
write|Proto Cuneiform|𒖨𒖵𒗃𒗑𒗞𒗬𒗺𒘇𒘕𒘣𒘰𒘾
read|Psalter Pahlavi|𐮀𐮁𐮃𐮄𐮆𐮇𐮉𐮊𐮌𐮍𐮏𐮐
read|Rejang|ꤰꤱꤳꤵꤷꤹꤻꤽꤿꥁꥃꥅ
read|Runic|ᚠᚦᚭᚴᚻᛂᛉᛐᛗᛞᛥᛲ
rws|Samaritan|ࠀࠂࠄࠆࠈࠊࠌࠎࠐࠒࠔࠚ
rws|Saurashtra|ꢂꢆꢊꢎꢒꢖꢛꢟꢣꢧꢫꢯ
read|Seal|𽀀𽀕𽀪𽁀𽁕𽁪𽂀𽂕𽂪𽃀𽃕𽃪
read|Sharada|𑆃𑆇𑆌𑆐𑆕𑆙𑆞𑆢𑆧𑆫𑆰𑇂
rws|Shavian|𐑐𐑔𐑘𐑜𐑠𐑤𐑨𐑬𐑰𐑴𐑸𐑼
read|Siddham|𑖀𑖄𑖈𑖌𑖑𑖕𑖙𑖝𑖢𑖦𑖪𑖮
read|Sidetic|𐥀𐥂𐥄𐥆𐥈𐥊𐥍𐥏𐥑𐥓𐥕𐥗
rws|SignWriting|𝠀𝠭𝡚𝢇𝢴𝣡𝤎𝤻𝥨𝦕𝧂𝧯
rws|Sinhala|අඉඎඓඛචඥඪදඵයෂ
read|Sogdian|𐼰𐼱𐼳𐼵𐼷𐼹𐼻𐼼𐼾𐽀𐽂𐽄
rws|Sora Sompeng|𑃐𑃒𑃔𑃖𑃘𑃚𑃜𑃞𑃠𑃢𑃤𑃦
read|Soyombo|𑩐𑩟𑩣𑩧𑩫𑩯𑩳𑩷𑩻𑩿𑪃𑪇
rws|Sundanese|ᮃᮆᮉᮌᮏᮒᮖᮙᮜᮟᮯᮼ
rws|Sunuwar|𑯀𑯂𑯅𑯈𑯋𑯍𑯐𑯓𑯖𑯘𑯛𑯞
rws|Syloti Nagri|ꠀꠃꠇꠊꠍꠐꠓꠕꠘꠛꠝꠠ
rws|Syriac|ܐܓܖܙܜܟܢܤܧܪܭݍ
rws|Tagalog|ᜀᜁᜃᜄᜆᜇᜉᜋᜌᜎᜏᜑ
rws|Tagbanwa|ᝠᝡᝢᝤᝥᝦᝨᝩᝪᝬᝮᝯ
rws|Tai Le|ᥐᥒᥕᥘᥛᥞᥡᥤᥧᥪᥭᥲ
rws|Tai Tham|ᨠᨤᨩᨭᨲᨶᨻᨿᩄᩈᩍᩑ
rws|Tai Viet|ꪀꪅꪊꪏꪔꪙꪞꪣꪨꪭꪶꪽ
rws|Tai Yo|𞛀𞛄𞛈𞛌𞛐𞛔𞛙𞛝𞛢𞛨𞛬𞛲
read|Takri|𑚀𑚃𑚇𑚋𑚎𑚒𑚖𑚙𑚝𑚡𑚤𑚨
rws|Tamil|ஃஇஊஐஔசடநமறழஷ
rws|Tangsa|𖩰𖩶𖩽𖪃𖪊𖪐𖪗𖪞𖪤𖪫𖪱𖪸
read|Tangut|𖿠𗀑𗀤𗀷𗁊𗁜𗁯𗂂𗂕𗂧𗂺𗃍
rws|Telugu|అఉఏకచటతనమళసౚ
rws|Thaana|ހރކމލސޓޖޚޝޠޣ
rws|Thai|กฅชฏดธฝยวหะโ
rws|Tibetan|ༀགྷཇཌཐཔཙཝཡཥཀྵྈ
rws|Tifinagh|ⴰⴴⴹⴾⵃⵇⵌⵑⵖⵚⵟⵤ
read|Tirhuta|𑒀𑒄𑒈𑒌𑒑𑒕𑒙𑒝𑒢𑒦𑒪𑒮
read|Todhri|𐗀𐗄𐗈𐗍𐗑𐗕𐗚𐗞𐗢𐗧𐗫𐗯
rws|Tolong Siki|𑶰𑶳𑶷𑶻𑶾𑷂𑷆𑷉𑷍𑷑𑷔𑷘
rws|Toto|𞊐𞊒𞊕𞊗𞊚𞊜𞊟𞊡𞊤𞊦𞊩𞊫
rws|Tulu Tigalari|𑎀𑎄𑎈𑎑𑎕𑎚𑎞𑎢𑎧𑎫𑎰𑎴
read|Ugaritic|𐎀𐎂𐎅𐎇𐎊𐎌𐎏𐎑𐎔𐎖𐎙𐎛
rws|Vai|ꔀꔕꔪꕀꕕꕪꖀꖕꖪꗀꗕꗪ
read|Vithkuqi|𐕰𐕵𐕼𐖂𐖈𐖏𐖗𐖜𐖣𐖩𐖯𐖶
rws|Wancho|𞋀𞋃𞋇𞋋𞋎𞋒𞋖𞋙𞋝𞋡𞋤𞋨
rws|Warang Citi|𑢠𑢥𑢪𑢰𑢵𑢻𑣀𑣅𑣋𑣐𑣖𑣛
rws|Yezidi|𐺀𐺃𐺇𐺋𐺎𐺒𐺖𐺙𐺝𐺡𐺤𐺨
rws|Yi|ꀀꀕꀪꁀꁕꁪꂀꂕꂪꃀꃕꃪ
read|Zanabazar Square|𑨀𑨍𑨑𑨔𑨘𑨛𑨟𑨢𑨦𑨩𑨭𑨰
write|Indus script|?
write|Rongorongo|?
write|Proto-Elamite|?
speak|Oral languages|∿∿∿
speak|Sign languages|∿∿∿
