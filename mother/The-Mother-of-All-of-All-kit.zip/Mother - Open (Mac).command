#!/bin/sh
# The Mother of All of All - opens the full-screen 4D wall of every script.
# (c) 2026 Mandeep S. Bhullar - SpinalXeno(TM). All rights reserved. SpinalXeno(TM) is a trademark of Mandeep S. Bhullar.
# fingerprint 25666eb2cf27368640bb41154733bfdc1f8a07b194aec7661659fc7b565155b3
F="$(cd "$(dirname "$0")" && pwd)/The Mother of All of All.html"
for A in "Google Chrome" "Microsoft Edge" "Brave Browser" "Chromium"; do
  if open -Ra "$A" 2>/dev/null; then open -na "$A" --args --kiosk --user-data-dir="${TMPDIR:-/tmp}/mother-of-all" --no-first-run "file://$F"; exit 0; fi
done
open "$F"   # Safari: press START, then F for full screen
