@echo off
rem The Father of All of All - opens the full-screen 4D wall of every script.
rem (c) 2026 Mandeep S. Bhullar - SpinalXeno(TM). All rights reserved. SpinalXeno(TM) is a trademark of Mandeep S. Bhullar.
rem fingerprint 25666eb2cf27368640bb41154733bfdc1f8a07b194aec7661659fc7b565155b3
chcp 65001 >nul
set "F=%~dp0The Father of All of All.html"
if not exist "%F%" (echo Missing "%F%" & pause & exit /b 1)
set "P=%TEMP%\father-of-all"
for %%B in (msedge chrome brave) do (
  where /q %%B && (start "" %%B --kiosk "%F%" --edge-kiosk-type=fullscreen --user-data-dir="%P%" --no-first-run & exit /b)
)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --kiosk "%F%" --edge-kiosk-type=fullscreen --user-data-dir="%P%" --no-first-run & exit /b)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --kiosk "%F%" --user-data-dir="%P%" --no-first-run & exit /b)
start "" "%F%"
