#!/bin/sh
# The Father of All of All - opens the full-screen 4D wall of every script.
# (c) 2026 Mandeep S. Bhullar - SpinalXeno(TM). All rights reserved. SpinalXeno(TM) is a trademark of Mandeep S. Bhullar.
# fingerprint 25666eb2cf27368640bb41154733bfdc1f8a07b194aec7661659fc7b565155b3
F="$(cd "$(dirname "$0")" && pwd)/The Father of All of All.html"
P="${TMPDIR:-/tmp}/father-of-all"
for B in chromium chromium-browser google-chrome google-chrome-stable brave-browser microsoft-edge; do
  command -v "$B" >/dev/null 2>&1 && exec "$B" --kiosk --user-data-dir="$P" --no-first-run "file://$F"
done
command -v firefox >/dev/null 2>&1 && exec firefox --kiosk "file://$F"
command -v xdg-open >/dev/null 2>&1 && exec xdg-open "$F"
echo "Open this file in any modern browser: $F"
