@echo off
rem Mother Sentinel: watches your open-source and secure-source code, flags anomalies, signals events to the wall.
rem Read-only. (c) 2026 Mandeep S. Bhullar - SpinalXeno(TM). All rights reserved. SpinalXeno(TM) is a trademark of Mandeep S. Bhullar.
rem fingerprint 25666eb2cf27368640bb41154733bfdc1f8a07b194aec7661659fc7b565155b3
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$f='%~f0';$s=[IO.File]::ReadAllText($f,[Text.Encoding]::UTF8);$a=$s.LastIndexOf('#'+'##PS');& ([ScriptBlock]::Create($s.Substring($a+6))) $f"
exit /b
###PS

# Mother Sentinel (Windows). Read-only: it never changes, uploads or deletes anything it watches.
$ErrorActionPreference='SilentlyContinue'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$Host.UI.RawUI.WindowTitle='Mother Sentinel'
$KIT=Split-Path -Parent $args[0]; $CONF=Join-Path $KIT 'sentinel.conf'; $OUT=Join-Path $KIT 'mother-events.js'; $LOG=Join-Path $KIT 'mother-events.log'; $EVERY=10
if(-not (Test-Path $CONF)){ @('# Mother Sentinel watch list.  kind|path   kinds: open (public, signed), secure (private), kit (this folder)','kit|.','# open|C:\path\to\public\project','# secure|C:\path\to\private\project') | Set-Content -Encoding UTF8 $CONF }
$W=@(); foreach($l in Get-Content -Encoding UTF8 $CONF){ if($l -match '^\s*(#|$)'){continue}; $k,$p=$l -split '\|',2; if(-not $p){continue}; $p=$p -replace '^~',$HOME; if($p -eq '.'){$p=$KIT}
  $W+=[pscustomobject]@{kind=$k;path=$p;name=$(if($p -eq $KIT){'kit'}else{Split-Path -Leaf $p});snap=$null;head='';s='wait';d='baseline…';sums=''} }
$EV=New-Object System.Collections.ArrayList; $script:n=0
$KS=@{}; $mf=Join-Path $KIT 'MANIFEST.sha256'; if(Test-Path $mf){ foreach($l in Get-Content $mf){ if($l -match '^(\w+)\s+\*?(.+)$'){ $KS[$matches[2]]=$matches[1] } } }
function now{ [long]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()) }
function jq($s){ '"'+(([string]$s) -replace '\\','\\' -replace '"','\"' -replace '[\x00-\x1f]',' ')+'"' }
function Ev($k,$src,$msg){ $t=now; $script:n++; [void]$EV.Add([pscustomobject]@{id="$t-$script:n";k=$k;src=$src;msg=$msg;t=$t}); while($EV.Count -gt 300){$EV.RemoveAt(0)}
  $c=@{ok='Green';bad='Red';wait='Gray'}[$k]; $m=@{ok='●';bad='○';wait='◌'}[$k]; Write-Host "$m $(Get-Date -f 'HH:mm:ss')  $src  " -NoNewline -ForegroundColor DarkGray; Write-Host $msg -ForegroundColor $c
  Add-Content -Encoding UTF8 $LOG "$(Get-Date -f s)`t$k`t$src`t$msg"
  if($k -eq 'bad'){ [Console]::Beep(330,250); try{ Add-Type -AssemblyName System.Windows.Forms; $b=New-Object System.Windows.Forms.NotifyIcon; $b.Icon=[System.Drawing.SystemIcons]::Warning; $b.Visible=$true; $b.ShowBalloonTip(8000,'Mother Sentinel · ANOMALY',"$src`: $msg",'Warning') }catch{} } }
function Feed{ $st=($W|%{ "{kind:$(jq $_.kind),name:$(jq $_.name),s:$(jq $_.s),d:$(jq $_.d)}" }) -join ','; $ev=($EV|%{ "{id:$(jq $_.id),k:$(jq $_.k),src:$(jq $_.src),msg:$(jq $_.msg),t:$($_.t)}" }) -join ','
  [IO.File]::WriteAllText("$OUT.tmp","window.__motherEvents={t:$(now),status:[$st],ev:[$ev]};`n",[Text.UTF8Encoding]::new($false)); Move-Item -Force "$OUT.tmp" $OUT }
function Scan($w){ $h=@{}; $root=(Resolve-Path $w.path).Path.TrimEnd('\')+'\'; Get-ChildItem -LiteralPath $w.path -Recurse -File -Force | ?{ $_.FullName -notmatch '\\(\.git|node_modules)\\' -and $_.Name -notmatch '^(mother-events\.(js|js\.tmp|log)|sentinel\.conf)$' } | %{ $h[$_.FullName.Substring($root.Length).Replace('\','/')]="$($_.LastWriteTimeUtc.Ticks)/$($_.Length)" }; $h }
function Secret($f){ try{ if((Get-Item -LiteralPath $f).Length -gt 2MB){return $false}; $x=[IO.File]::ReadAllText($f); return $x -match '-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}' }catch{ return $false } }
function Sha($f){ (Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLower() }
Write-Host 'THE MOTHER OF ALL OF ALL · SENTINEL' -ForegroundColor Green; Write-Host "watching $($W.Count) source(s) every ${EVERY}s · Ctrl+C to stop · read-only" -ForegroundColor DarkGray
Write-Host '© 2026 Mandeep S. Bhullar · SpinalXeno™' -ForegroundColor DarkGray; Write-Host ''
Ev 'wait' 'sentinel' ('Sentinel started · '+(($W|%{"$($_.kind):$($_.name)"}) -join ', '))
$git=[bool](Get-Command git -ErrorAction SilentlyContinue)
try{ while($true){
  foreach($w in $W){ $tag="$($w.kind) $($w.name)"
    if(-not (Test-Path -LiteralPath $w.path)){ if($w.s -ne 'bad'){Ev 'bad' $tag "Folder missing or drive unplugged: $($w.path)"}; $w.s='bad'; $w.d='missing'; $w.snap=$null; continue }
    $now=Scan $w; $old=$w.snap; $add=@();$chg=@();$del=@(); $flag=0
    if($old){ foreach($f in $now.Keys){ if(-not $old.ContainsKey($f)){$add+=$f}elseif($old[$f] -ne $now[$f]){$chg+=$f} }; foreach($f in $old.Keys){ if(-not $now.ContainsKey($f)){$del+=$f} } }
    $tot=$add.Count+$chg.Count+$del.Count
    if($tot){ $k='ok'; $add|select -First 8|%{Ev $k $tag "Added: $_"}; $chg|select -First 8|%{Ev $k $tag "Changed: $_"}; $del|select -First 8|%{Ev $k $tag "Deleted: $_"}
      if($tot -gt 25 -or $del.Count -gt 5){ Ev 'bad' 'anomaly detector' "$tag`: burst of $tot changes in ${EVERY}s" }
      foreach($f in $add+$chg){ if(Secret (Join-Path $w.path $f)){ $flag++; Ev 'bad' $tag ($(if($w.kind -eq 'open'){'SECRET IN PUBLIC CODE: '}else{'Secret found: '})+"$f contains a private key or token") } } }
    $w.snap=$now; $d=@("$($now.Count) files")
    if($w.kind -eq 'kit' -and $KS.Count -and (-not $old -or $tot)){ $bad=0; foreach($f in $KS.Keys){ $p=Join-Path $KIT $f; if(-not (Test-Path -LiteralPath $p) -or (Sha $p) -ne $KS[$f]){ $bad++; Ev 'bad' $tag "Kit tampered: $f differs from the signed manifest" } }; $w | Add-Member -Force kb $bad }
    if($w.kind -eq 'kit' -and $KS.Count){ $d+=$(if($w.kb){"$($w.kb) tampered"}else{'manifest intact'}); $flag+=$w.kb }
    $sf=Join-Path $w.path 'signature/SHA256SUMS'
    if($w.kind -eq 'open' -and (Test-Path $sf) -and (-not $old -or $tot)){ $bad=0;$all=0; foreach($l in Get-Content $sf){ if($l -match '^(\w+)\s+\*?(.+)$'){ $all++; $p=Join-Path $w.path $matches[2]; if(-not (Test-Path -LiteralPath $p)){ $bad++; Ev 'bad' $tag "Signed file missing: $($matches[2])" } elseif((Sha $p) -ne $matches[1]){ $bad++; Ev 'bad' $tag "Unsigned change: $($matches[2])" } } }
      $w.sums=$(if($bad){"$bad problem(s) in $all signed files"}else{"$all files match the signed list"}); $w | Add-Member -Force sb $bad }
    if($w.sums){ $d+=$w.sums; $flag+=$w.sb }
    if($git -and (Test-Path (Join-Path $w.path '.git'))){ $h=(git -C $w.path log -1 --format='%h·%s' 2>$null); if($w.head -and $h -ne $w.head){ Ev 'ok' $tag "New commit $h" }; $w.head=$h; $dirty=@(git -C $w.path status --porcelain 2>$null).Count; $d+="git $h"+$(if($dirty){" · $dirty uncommitted"}else{' · clean'}) }
    $w.s=$(if($flag){'bad'}else{'ok'}); $w.d=$d -join ' · '; if(-not $old){ Ev 'ok' $tag ('Baseline: '+$w.d) } }
  Feed; Start-Sleep -Seconds $EVERY } }
finally{ Ev 'wait' 'sentinel' 'Sentinel stopped'; Feed }

